﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cube : MonoBehaviour {
    Vector3 tempPos = new Vector3 ();
    Vector3 pos = new Vector3 ();
    public float amplitude = 0.5f;
    public float frequency = 1f;

    void Start() {
        // rotate
        var rigidbod = GetComponent<Rigidbody>();
        rigidbod.angularVelocity = Random.insideUnitSphere;

        // float variables
        pos = transform.position;
    }
    void Update(){
        // float effect
        tempPos = pos;
        tempPos.y += Mathf.Sin (Time.fixedTime * Mathf.PI * frequency) * amplitude;

        transform.position = tempPos;
    }
}
