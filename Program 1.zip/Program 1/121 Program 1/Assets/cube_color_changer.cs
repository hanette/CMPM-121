﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cube_color_changer : MonoBehaviour {
    public MeshRenderer cube1;
    public MeshRenderer cube2;
    public MeshRenderer cube3;
    public Slider red;
    public Slider green;
    public Slider blue;

    public void OnEdit(){
        Color color1 = cube1.material.color;
        Color color2 = cube2.material.color;
        Color color3 = cube3.material.color;
        color1.r = red.value;
        color1.g = green.value;
        color1.b = blue.value;
        color2.r = red.value;
        color2.g = green.value;
        color2.b = blue.value;
        color3.r = red.value;
        color3.g = green.value;
        color3.b = blue.value;
        cube1.material.color = color1;
        cube1.material.SetColor("_EmissionColor", color1);
        cube2.material.color = color2;
        cube2.material.SetColor("_EmissionColor", color2);
        cube3.material.color = color3;
        cube3.material.SetColor("_EmissionColor", color3);
        print(cube1.material.GetColor("_EmissionColor"));

    }
}
