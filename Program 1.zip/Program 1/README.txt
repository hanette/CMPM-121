Hanette Le
hanle
10/6/19
CMPM 121: Program 1

Description: 

This program plays with position, rotation, scale, colors, and sliders. 
- Cube floats up and down the y-axis.
- Cube rotating in place.
- The three cubes are all scaled to different sizes.
- Cube changes color depending on user input for the sliders

It also plays with saving and loading the object's state through cube.cs and cube_color_change.cs. 
- cube.js loads components of RigidBody and saves its angular velocity to be a random unit. 
- cube_color_change.cs sets color to cube and calls it to print on console.

The program displays three cubes all scaled in different sizes are rotating while its y-position floats up and down. Colors can be changed through sliders.


- (extra credit) Implemented a UI with three sliders that controls the color of the cubes.