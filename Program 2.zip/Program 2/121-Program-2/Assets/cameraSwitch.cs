using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cameraSwitch : MonoBehaviour {
    public GameObject thirdPerson; // 0
    public GameObject firstPerson; // 1s
    public int mode;

    void Start(){
        mode = 1;
    }
    // Update is called once per frame
    public void ChangeMode() {
            // change mode for buttons
            if(mode == 1){ // if first person
                mode = 0;
            } else {
                mode = 1;
            }
            StartCoroutine(CameraChange());

    }
    // switch mode
    IEnumerator CameraChange() {
        yield return new WaitForSeconds (0.01f);
        if(mode == 0){
            thirdPerson.SetActive(true);
            firstPerson.SetActive(false);
        }

        if(mode == 1){
            thirdPerson.SetActive(false);
            firstPerson.SetActive(true);
        }
    }
}
