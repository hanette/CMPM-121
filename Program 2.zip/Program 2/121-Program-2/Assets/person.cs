﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class person : MonoBehaviour {

    CharacterController characterController;
    // movement
    public float speed = 20f;
    public float jumpSpeed = 15f;
    public float gravity = 20f;
    private Vector3 movement = Vector3.zero;

    // mouse cam control
    public float RotationSpeed = 1;
    public Transform Target, Player;
    float mouseX, mouseY;
    bool locke = true;

    // score
    private int score;
    public Text scoreText;

    // Start is called before the first frame update
    void Start() {
        characterController = GetComponent<CharacterController>();
        score = 0;
        SetScoreText();
        Cursor.lockState = CursorLockMode.Locked;

    } // end of start

    // Update is called once per frame
    void Update() {
        if (characterController.isGrounded) { // play cant move
            float horizon = Input.GetAxis("Horizontal");
            float vertic = Input.GetAxis("Vertical");

            movement = new Vector3(horizon, 0.0f, vertic);
            movement *= speed;
        }
        if (Input.GetButton("Jump")) { // jump and fly like flappy bird
            movement.y = jumpSpeed;
        }

        // Add gravity
        movement.y -= gravity * Time.deltaTime;

        // Move the controller
        characterController.Move(movement * Time.deltaTime);
        transform.Translate(movement*Time.deltaTime, Space.Self);

        // Unlock cursor
        if(Input.GetKeyDown(KeyCode.Q)){
            if (locke){
                Cursor.lockState = CursorLockMode.None;
                locke = false;
            } else if (!locke){
                Cursor.lockState = CursorLockMode.Locked;
                locke = true;
            }
        }
        // Camera rotation
        CamRotation();
    } // end of update

    void CamRotation(){
        mouseX += Input.GetAxis("Mouse X")*RotationSpeed;
        mouseY -= Input.GetAxis("Mouse Y")*RotationSpeed;
        mouseY = Mathf.Clamp(mouseY, -35, 60);
        transform.LookAt(Target);

        Target.rotation = Quaternion.Euler(mouseY, mouseX, 0);
        Player.rotation = Quaternion.Euler(0, mouseX, 0);
    }

    void OnTriggerEnter(Collider other){
       if (other.gameObject.CompareTag ("Coin")){
           other.gameObject.SetActive (false);
           score += 1;
           SetScoreText();
       }
   }

   void SetScoreText (){
        scoreText.text = "Score: " + score.ToString ();
    }
}
