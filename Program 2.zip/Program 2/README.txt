Hanette Le
hanle
10/17/19
CMPM 121: Program 2

Description:

This program plays with player movement, first person camera, third person camera, camera mouse movement, locking and unlocking mouse, coins, and score.

FEATURES:
- Cube is controlled with WASD.
- Unlocking cursor is with Q key.
- Pressing the button will toggle between first person and third person camera.
  (Click outside of the button after or else Unity will think your cursor is still on the button.)
- Spacebar allows player to jump/fly flappy bird style.
- Walls prevent cube from falling.
- Golden spheres are collectable objects that gives player 1 point per sphere.

EXTRA CREDIT:
- Implemented locking and unlocking cursor with "Q" key.
- Mouse controls camera's vision
- Jump/fly is controlled with spacebar and works by gravity and y position
