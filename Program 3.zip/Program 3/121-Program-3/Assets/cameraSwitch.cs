using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class cameraSwitch : MonoBehaviour {
    public GameObject room1;
    public GameObject room2;
    public GameObject room3;
    public GameObject room4;
    public GameObject room5;
    public GameObject room6;
    public GameObject player;
    public float watch;
    public float watchy;
    Vector3 cam4Pos;

    void Start(){
        watch = 0f;
        watchy = 17.69f;
    }
    // Update is called once per frame
    public void Update() {
        cam4Pos = room4.transform.position;

            // change camera depending on which room
            if(GameObject.Find("Player").transform.position.x <= -6.5){
                room1.SetActive(true);
                room2.SetActive(false);
                room3.SetActive(false);
                room4.SetActive(false);
                room5.SetActive(false);
                room6.SetActive(false);
            } else if(GameObject.Find("Player").transform.position.x <= -2.8){
                room1.SetActive(false);
                room2.SetActive(true);
                room3.SetActive(false);
                room4.SetActive(false);
                room5.SetActive(false);
                room6.SetActive(false);
            } else if(GameObject.Find("Player").transform.position.x <= 0.45){
                room1.SetActive(false);
                room2.SetActive(false);
                room3.SetActive(true);
                room4.SetActive(false);
                room5.SetActive(false);
                room6.SetActive(false);
            } else if(GameObject.Find("Player").transform.position.x <= 7.5){
                room1.SetActive(false);
                room2.SetActive(false);
                room3.SetActive(false);
                room4.SetActive(true);
                room5.SetActive(false);
                room6.SetActive(false);

                // move right
                if(GameObject.Find("Player").transform.position.x >= cam4Pos.x){
                    cam4Pos.x += 0.1f;
                    room4.transform.position = cam4Pos;
                }
                //move left
                if(GameObject.Find("Player").transform.position.x < cam4Pos.x){
                    cam4Pos.x -= 0.1f;
                    room4.transform.position = cam4Pos;
                }
            } else if(GameObject.Find("Player").transform.position.x <= 17.3){
                room1.SetActive(false);
                room2.SetActive(false);
                room3.SetActive(false);
                room4.SetActive(false);
                room5.SetActive(true);
                room6.SetActive(false);
            } else {
                room1.SetActive(false);
                room2.SetActive(false);
                room3.SetActive(false);
                room4.SetActive(false);
                room5.SetActive(false);
                room6.SetActive(true);

                // move it left and right
                if (player.transform.position.z < watch){
                    room6.transform.Rotate(0, -0.5f, 0);
                    room6.transform.Rotate(0, -0.5f, 0);
                    room6.transform.Rotate(0, -0.7f, 0);
                    watch -= 0.5f;
                }
                if (player.transform.position.z > watch){
                    room6.transform.Rotate(0, 0.5f, 0);
                    room6.transform.Rotate(0, 0.5f, 0);
                    room6.transform.Rotate(0, 0.7f, 0);
                    watch += 0.5f;
                }

                // move it up and down
                if (player.transform.position.x < watchy){
                    room6.transform.Rotate(-0.5f, 0, 0);
                    watchy -= 0.8f;
                }
                if (player.transform.position.x > watchy){
                    room6.transform.Rotate(0.5f, 0, 0);
                    watchy += 0.8f;
                }
            }
    }
}
