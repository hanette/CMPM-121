﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightSwitch : MonoBehaviour {
    public GameObject Flashlight;
    private bool lighton;

    void Start(){
        lighton = true;
    }

    // Update is called once per frame
    void Update(){
            if(Input.GetKeyDown(KeyCode.F)){
                if(!lighton){
                    Flashlight.SetActive(true);
                    lighton = true;
                } else {
                    Flashlight.SetActive(false);
                    lighton = false;
                }
            }
    }
}
