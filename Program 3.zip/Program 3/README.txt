Hanette Le
hanle
10/31/19
CMPM 121: Program 3

Description:

Happy Halloween!
This program plays with light and camera by switching camera when player enters different rooms. First three rooms are camera on the wall, fourth room has a camera in the hallway that follows the player on one axis, fifth room is a camera that positioned with the player, sixth room is a camera on the wall that rotates to follow the player. The cubes in the rooms alternate from baked to realtime. All floors and and walls are baked.

FEATURES:
- Cube is controlled with WASD.
   - W is left, A is down, S is right, D is up.
   - F is on/off the flashlight.camera.
- Spacebar allows player to jump/fly flappy bird style. (You may fall.)

EXTRA CREDIT:
- Press "F" to turn on/off the flashlight
