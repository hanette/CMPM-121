Hanette Le
hanle
11/10/19
CMPM 121: Program 4

Description:

This program plays with shadertoy by using shader (HLSL) to change the material of game objects. 

FEATURES:
I used shader 4 on the plane and created my own shader material!

URL of shadertoy 4: https://www.shadertoy.com/view/tsBGDD

EXTRA CREDIT:
- The pink marble style material sphere is my own shader creation.

NOTE:
To be honest, I tried creating shadertoy 1 but the snoise function got really complicated to convert to HLSL and somehow resulted into a white marble style. It looks like _Time.y didn't work or got too small through the snoise function that it didn't move and the colors probably got implement incorrectly. As a result, I altered the color to be more pink and called it a day due to the lack of time. I would really like to understand how it would work though. I'm fairly new to GLSL and HLSL which is probably why translating was more difficult than I expected.

Shadertoy 1: https://www.shadertoy.com/view/3d2GDW
